# Birla College Three.js floor maps

This package renders the supplied DXF as live Three.js vector linework (not a raster image).

## Run
```bash
npm install
npm run dev
```

## Existing app integration
- Install dependencies: `npm install three @react-three/fiber @react-three/drei`
- Copy `src/Maps/mainbuilding/` into your project.
- Import:
```tsx
import { Main_Floor_0 } from "./Maps/mainbuilding/MainGround";
import { Main_Floor_1 } from "./Maps/mainbuilding/MainFirst";
```
- Pass your shared `onNavigate` prop. Floor IDs are `mainGround` and `mainFirst`.

## Navigation arrows
The floor plans retain the original CAD linework, including stair/arrow markings where represented by DXF geometry. The explicit UI buttons are labeled **First floor ↑** and **Ground floor ↓** as navigation controls. The DXF geometry itself does not reliably encode a semantic “up/down” property for every arrow, so do not interpret every triangular/arrow-like symbol as stair direction without checking the source drawing.

## Notes
- This is a 2.5D-style viewer: flat CAD vector geometry with a subtle depth plane and a slight pseudo-3D presentation. It is not a reconstructed 3D building model.
- Scroll to zoom; drag to pan. The map is clipped to its viewport.
- The original file has a very dense right-hand plan. The extracted vector data preserves linework; performance depends on the target device.
- Room labels are shown progressively as you zoom in.
