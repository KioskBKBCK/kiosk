import { Canvas } from '@react-three/fiber';
import { OrbitControls, OrthographicCamera, Text } from '@react-three/drei';
import { Suspense, useMemo } from 'react';
import * as THREE from 'three';
import ground from './data/ground.json';
import first from './data/first.json';

type CADText = {x:number;y:number;text:string;height:number;rotation:number};
type CADSegment = {a:[number,number];b:[number,number];layer:string};
type CADMap = {name:string;segments:CADSegment[];texts:CADText[];bounds:{minX:number;maxX:number;minY:number;maxY:number}};
const plans: Record<'ground'|'first', CADMap> = {ground: ground as CADMap, first: first as CADMap};

function CADLinework({plan}:{plan:CADMap}) {
  const positions = useMemo(() => {
    const out:number[] = [];
    for (const s of plan.segments) out.push(s.a[0], -s.a[1], 0.08, s.b[0], -s.b[1], 0.08);
    return new Float32Array(out);
  }, [plan]);
  const geometry = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    return g;
  }, [positions]);
  return <lineSegments geometry={geometry} frustumCulled={false}>
    <lineBasicMaterial color="#526779" transparent opacity={0.9} />
  </lineSegments>;
}

function RoomLabels({plan,zoom}:{plan:CADMap;zoom:number}) {
  // The source CAD uses many small labels; reveal them progressively as users zoom in.
  const visible = zoom > 1.35 ? plan.texts : plan.texts.filter(t => t.text.length > 7 && !/^\d+$/.test(t.text));
  return <>{visible.map((t,i) => <Text key={`${t.x}-${t.y}-${i}`}
    position={[t.x, -t.y, 0.16]} rotation={[0,0,-THREE.MathUtils.degToRad(t.rotation)]}
    fontSize={Math.max(0.13, Math.min(0.42, t.height*0.85))}
    color="#1f2937" anchorX="center" anchorY="middle" maxWidth={5}
    outlineWidth={0.012} outlineColor="#f8fafc">{t.text}</Text>)}</>;
}

export function FloorMap3D({floor='ground',onNavigate}:{floor?:'ground'|'first';onNavigate?:(id:string)=>void}) {
  const plan = plans[floor];
  const width=plan.bounds.maxX-plan.bounds.minX;
  const height=plan.bounds.maxY-plan.bounds.minY;
  const [zoom,setZoom] = useMemo(() => [1,()=>{}] as const, []); // camera zoom is controlled by OrbitControls
  return <div className="floor-map-canvas">
    <Canvas dpr={[1,2]} gl={{antialias:true,alpha:false}} onCreated={({gl})=>gl.setClearColor('#f8fafc',1)}>
      <OrthographicCamera makeDefault position={[width/2,height/2,100]} zoom={Math.min(10,Math.max(2,900/Math.max(width,height)))} />
      <ambientLight intensity={1.5}/>
      <mesh position={[width/2,height/2,-0.1]}><planeGeometry args={[width+2,height+2]}/><meshBasicMaterial color="#f8fafc"/></mesh>
      <gridHelper args={[Math.max(width,height)*1.4,40,'#e2e8f0','#e2e8f0']} position={[width/2,height/2,-0.05]} rotation={[Math.PI/2,0,0]} />
      <CADLinework plan={plan}/>
      <Suspense fallback={null}><RoomLabels plan={plan} zoom={zoom}/></Suspense>
      <OrbitControls makeDefault enableRotate={false} enablePan enableZoom zoomSpeed={0.7} panSpeed={0.8} screenSpacePanning minZoom={0.7} maxZoom={80}/>
    </Canvas>
    <div className="map-hint">Drag to pan · Scroll to zoom · CAD vector linework</div>
  </div>;
}
export function Main_Floor_0({onNavigate}: {onNavigate?:(id:string)=>void}) {
  return <section className="map-shell"><header><div><small>MAIN BUILDING</small><h2>Ground Floor</h2></div><button onClick={()=>onNavigate?.('mainFirst')}>First floor ↑</button></header><FloorMap3D floor="ground" onNavigate={onNavigate}/></section>;
}
export function Main_Floor_1({onNavigate}: {onNavigate?:(id:string)=>void}) {
  return <section className="map-shell"><header><div><small>MAIN BUILDING</small><h2>First Floor</h2></div><button onClick={()=>onNavigate?.('mainGround')}>Ground floor ↓</button></header><FloorMap3D floor="first" onNavigate={onNavigate}/></section>;
}
