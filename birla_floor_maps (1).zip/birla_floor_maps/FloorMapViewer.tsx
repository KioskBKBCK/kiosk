import { useEffect, useRef, useState } from "react";
import type { MapProps } from "./MapProps";
import "./FloorMapViewer.css";

type FloorMapViewerProps = MapProps & {
  title: string;
  svgMarkup: string;
  otherFloorId: string;
  otherFloorLabel: string;
};

/** A clipped, pannable and zoomable vector map. The SVG stays vector-sharp at every zoom. */
export function FloorMapViewer({
  onNavigate,
  title,
  svgMarkup,
  otherFloorId,
  otherFloorLabel,
}: FloorMapViewerProps) {
  const viewportRef = useRef<HTMLDivElement>(null);
  const dragRef = useRef({ active: false, x: 0, y: 0, originX: 0, originY: 0 });
  const [zoom, setZoom] = useState(1.12);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [dragging, setDragging] = useState(false);

  const clampZoom = (value: number) => Math.max(0.65, Math.min(5, value));
  const changeZoom = (next: number) => setZoom(clampZoom(next));

  useEffect(() => {
    const el = viewportRef.current;
    if (!el) return;
    const onWheel = (event: WheelEvent) => {
      event.preventDefault();
      changeZoom(zoom + (event.deltaY < 0 ? 0.16 : -0.16));
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
  }, [zoom]);

  const pointerDown = (event: React.PointerEvent<HTMLDivElement>) => {
    if (event.button !== 0) return;
    dragRef.current = { active: true, x: event.clientX, y: event.clientY, originX: offset.x, originY: offset.y };
    setDragging(true);
    event.currentTarget.setPointerCapture(event.pointerId);
  };
  const pointerMove = (event: React.PointerEvent<HTMLDivElement>) => {
    if (!dragRef.current.active) return;
    setOffset({
      x: dragRef.current.originX + event.clientX - dragRef.current.x,
      y: dragRef.current.originY + event.clientY - dragRef.current.y,
    });
  };
  const pointerUp = () => {
    dragRef.current.active = false;
    setDragging(false);
  };
  const reset = () => { setZoom(1.12); setOffset({ x: 0, y: 0 }); };

  return (
    <section className="floor-map-panel" aria-label={`${title} map`}>
      <div className="floor-map-toolbar">
        <div>
          <strong>{title}</strong>
          <span className="floor-map-hint">Drag to move · Scroll or use +/- to zoom</span>
        </div>
        <div className="floor-map-actions">
          <button type="button" onClick={() => changeZoom(zoom - 0.2)} aria-label="Zoom out">−</button>
          <span className="floor-map-zoom">{Math.round(zoom * 100)}%</span>
          <button type="button" onClick={() => changeZoom(zoom + 0.2)} aria-label="Zoom in">+</button>
          <button type="button" onClick={reset}>Reset</button>
          <button type="button" onClick={() => onNavigate(otherFloorId)}>{otherFloorLabel}</button>
        </div>
      </div>
      <div
        ref={viewportRef}
        className={`floor-map-viewport ${dragging ? "is-dragging" : ""}`}
        onPointerDown={pointerDown}
        onPointerMove={pointerMove}
        onPointerUp={pointerUp}
        onPointerCancel={pointerUp}
        onLostPointerCapture={pointerUp}
      >
        <div
          className={`floor-map-art ${zoom >= 1.45 ? "show-room-labels" : ""}`}
          style={{ transform: `translate(calc(-50% + ${offset.x}px), calc(-50% + ${offset.y}px)) scale(${zoom})` }}
          dangerouslySetInnerHTML={{ __html: svgMarkup }}
        />
        <div className="floor-map-scale-note">Vector plan · Room labels appear as you zoom in</div>
      </div>
    </section>
  );
}
