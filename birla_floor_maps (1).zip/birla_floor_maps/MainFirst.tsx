import type { MapProps } from "./MapProps";
import { FloorMapViewer } from "./FloorMapViewer";
import firstSvg from "./assets/main-first.svg?raw";

export function Main_Floor_1({ onNavigate }: MapProps) {
  return <FloorMapViewer title="Main Building · First Floor" svgMarkup={firstSvg} onNavigate={onNavigate} otherFloorId="mainGround" otherFloorLabel="← Ground floor" />;
}
