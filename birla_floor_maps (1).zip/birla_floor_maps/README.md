# Birla College Main Building — interactive floor maps

The DXF file contains two plans side-by-side. The left plan is extracted as the ground floor and the right plan as the first floor. They are rendered as vector SVG (not a raster screenshot), so the linework remains sharp while zooming.

## Files
- `MainGround.tsx` exports `Main_Floor_0`
- `MainFirst.tsx` exports `Main_Floor_1`
- `FloorMapViewer.tsx` + `FloorMapViewer.css` provide the clipped viewport, drag-to-pan, wheel/buttons to zoom, reset, and floor switching
- `MapProps.ts` is the shared `onNavigate` prop type
- `assets/main-ground.svg`, `assets/main-first.svg` are the extracted vector plans

## Use in a Vite React + TypeScript app
Copy the files and `assets` directory into your source tree. Vite supports importing SVG as raw markup with `?raw` by default. If your project uses a restrictive TypeScript setup, add `src/vite-env.d.ts` with `/// <reference types="vite/client" />`.

Import the maps in your existing app:
```tsx
import { Main_Floor_0 } from "./Maps/mainbuilding/MainGround";
import { Main_Floor_1 } from "./Maps/mainbuilding/MainFirst";
```

Your navigation IDs need to include `mainGround` and `mainFirst`, and `onNavigate` must handle those IDs. If your shared `MapProps` file already exists, keep that file and adjust the import paths in the two floor components and `FloorMapViewer.tsx` to match it.

## Notes
The original CAD file contains extensive linework, including repeated CAD details. The SVG conversion preserves vector linework and room text, while filtering dimension annotations and repeated fixture-size notes for readability. The floor switching control uses `mainGround` and `mainFirst` IDs; change them if your app uses different IDs.
