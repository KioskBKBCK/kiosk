import type { MapProps } from "./MapProps";
import { FloorMapViewer } from "./FloorMapViewer";
import groundSvg from "./assets/main-ground.svg?raw";

export function Main_Floor_0({ onNavigate }: MapProps) {
  return <FloorMapViewer title="Main Building · Ground Floor" svgMarkup={groundSvg} onNavigate={onNavigate} otherFloorId="mainFirst" otherFloorLabel="First floor →" />;
}
